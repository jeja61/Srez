﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClassLibrary;

namespace AppSrez
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent(); 
            
            double[,] values = {Class1.};

            PlotRadar.Plot.AddRadar(values);

            // improve plot styling
            PlotRadar.Plot.Frameless();
            PlotRadar.Plot.Grid(enable: false);
            PlotRadar.Refresh();

            double[] values2 = { 778, 283, 184, 76, 43 };
            PlotPie.Plot.AddPie(values2);
            PlotPie.Refresh();


            double[] value3 = { 26, 20, 23, 7, 16 };
            PlotGraph.Plot.AddBar(value3);
            PlotGraph.Plot.SetAxisLimits(yMin: 0);
            PlotGraph.Plot.SaveFig("bar_quickstart.png");
            PlotGraph.Refresh();
        }

    }
}

