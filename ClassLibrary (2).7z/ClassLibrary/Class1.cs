﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{

    public static class Class1
    {
        public static List<string> markTypeList = new List<string>() { "Сидоров С.С.", "Петров П.П.", "Иванов И.И." };
        public class Student
        {
            public string fio;
            public int year;
            public int group;
        }
        public class Mark
        {
            public DateTime Date { get; set; }
            public Student StudentData { get; set; }
            public string Estimation;
        }

        public static double MinAVG(string[] marks)
        {
            double result;
            List<double> marksList = new List<double>();

            foreach (string Mark in marks)
            {
                try
                {
                    double value = Convert.ToDouble(Mark);
                    marksList.Add(value);
                }
                catch (Exception)
                {
                    continue;
                }
            }

            result = marksList.Average();
            return Math.Truncate(result);
        }

        public static int GetCountTruancy(string[] marks2)
        {
            //List<int> Years = marks.Select(c => c.date.Year).ToList();
            //int[] result = new int[Years.Count * 12];
            //int counter = 0;

            //foreach (int year in Years)
            //{
            //    for (int i = 1; i <= 12; i++)
            //    {
            //        List<Mark> currentMonth = marks.Where(c => c.date.Month == i && c.date.Year == year).ToList();

            //        result[counter++] = currentMonth.Where(c => c.Estimation == category).Count();
            //    }
            //}
            //return result;
            int k = 0;
            int result;
            List<String> marksList = new List<String>();
            System.Collections.IList list = marks2;
            for (int i = 0; i < list.Count; i++)
            {
                string Mark = (string)list[i];
                try
                {
                    String value = Mark;
                    marksList.Add(value);
                    if (marksList[i] == "н")
                    {
                        k += 1;
                    }

                }
                catch (Exception)
                {
                    continue;
                }
            }
            result = k;
            return result;
        }
        public static int GetCountTruancy2(string[] marks3)
        {
            int k = 0;
            int result;
            List<String> marksList = new List<String>();
            System.Collections.IList list = marks3;
            for (int i = 0; i < list.Count; i++)
            {
                string Mark = (string)list[i];
                try
                {
                    String value = Mark;
                    marksList.Add(value);
                    if (marksList[i] == "б")
                    {
                        k += 1;
                    }

                }
                catch (Exception)
                {
                    continue;
                }
            }
            result = k;
            return result;
        }

        public static string GetStudNumber(DateTime year, int group, string fio)
        {
            var fullName = fio.Split(' ');
            return $"{fullName[0].Substring(0, 1)}.{fullName[1].Substring(0, 1)}.{fullName[2].Substring(0, 1)} {group} {year:yyyy}";

        }

        public static List<Mark> GetMarks(DateTime now, List<Student> students)
        {
            Random rand = new Random();
            List<Mark> result = new List<Mark>();
            List<double> marksList = new List<double>();
            for (int i = now.Day; i < now.Day + 10; i++)
            {
                DateTime current = new DateTime(now.Year, now.Month, i);
                foreach (Student student in students)
                {
                    string pushData = markTypeList[rand.Next(0, 3)];

                    result.Add(new Mark() { Date = current, StudentData = student, Estimation = pushData });
                }
            }

            return result;
        }
    }
}
